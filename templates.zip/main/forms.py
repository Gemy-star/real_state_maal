from django import forms
from .models import Contact , ProjectRequest , JobRequest 


class JobRequestForm(forms.ModelForm):
    class Meta:
        model = JobRequest
        fields = '__all__'
        labels = {
            "name": " الاسم الثلاثي ",
            "field": " التخصص  ",
            "cv": " المرفقات وشهادات الخبرة ",
        }



class ContactForm(forms.ModelForm):
    class Meta:
        model = Contact
        fields = '__all__'
        labels = {
            "name": "الأسم ",
            "email": " البريد الأكترونى ",
            "phone": " الجوال ",
            "subject": " العنوان ",
            "message": " الرسالة ",

        }



class ProjectRequestForm(forms.ModelForm):
    class Meta:
        model = ProjectRequest
        fields = '__all__'
        labels = {
            "name": "الأسم ",
            "email": " البريد الأكترونى ",
            "phone": " الجوال ",
            "description": " وصف المشروع ",
            "project_file": " ارفاق ملف ",

        }

